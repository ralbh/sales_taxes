package com.IDMConsulting.sales_taxes.classi;


public class Output {
    
	private double tasseFinali;
	private double cifraFinale;


	public double getTasseFinali() {
		return tasseFinali;
	}


	public void setTasseFinali(double tasseFinali) {
		this.tasseFinali = tasseFinali;
	}


	public double getCifraFinale() {
		return cifraFinale;
	}


	public void setCifraFinale(double cifraFinale) {
		this.cifraFinale = cifraFinale;
	}


	@Override
	public String toString() {
		return "Output [tasseFinali=" + tasseFinali + ", cifraFinale=" + cifraFinale + "]";
	}
   
	
}
