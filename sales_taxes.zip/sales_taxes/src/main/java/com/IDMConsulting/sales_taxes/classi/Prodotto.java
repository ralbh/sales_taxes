package com.IDMConsulting.sales_taxes.classi;

public class Prodotto {
   
	private String name;
	private double prezzo;
	private double prezzoTasse;
	private boolean imported;
	private boolean esente;
	
	
	
	public Prodotto(String name, double prezzo, double prezzoTasse, boolean imported, boolean esente) {
		super();
		this.name = name;
		this.prezzo = prezzo;
		this.prezzoTasse = prezzoTasse;
		this.imported = imported;
		this.setEsente(esente);
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public boolean isImported() {
		return imported;
	}
	public void setImported(boolean imported) {
		this.imported = imported;
	}

	public double getPrezzo() {
		return prezzo;
	}
	public void setPrezzo(double prezzo) {
		this.prezzo = prezzo;
	}
	public double getPrezzoTasse() {
		return prezzoTasse;
	}
	public void setPrezzoTasse(double prezzoTasse) {
		this.prezzoTasse = prezzoTasse;
	}
	public boolean isEsente() {
		return esente;
	}
	public void setEsente(boolean esente) {
		this.esente = esente;
	}
	@Override
	public String toString() {
		return "Prodotto [name=" + name + ", prezzoTasse=" + prezzoTasse + "]";
	}

   
	
}
