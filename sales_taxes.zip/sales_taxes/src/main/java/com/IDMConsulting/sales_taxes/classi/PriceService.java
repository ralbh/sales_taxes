package com.IDMConsulting.sales_taxes.classi;


import java.util.ArrayList;

public class PriceService {

	private ArrayList<Prodotto> prodotti= new ArrayList<Prodotto>();
	private double tasseTotali;
	private double prezzoTotale;


	public Output getCalcoloPrezzo(Prodotto p) {
		Output out= new Output();
		double tasseProdotto = 0.0;
		if(p==null) {
			System.out.println("Non è stato inserito nessun input");
		}
		else {
			if((p.isEsente()) && (p.isImported()==false)) {
				p.setPrezzoTasse(p.getPrezzo());
			}
			if((p.isEsente()==false) && (p.isImported()==false)) {
				tasseProdotto =Util.arrotondoCifra((p.getPrezzo()*0.10));
				p.setPrezzoTasse(Util.decimali(tasseProdotto+p.getPrezzo()));
			}

			if(p.isImported() && (p.isEsente()==false)) {
				tasseProdotto =Util.arrotondoCifra((p.getPrezzo()*0.15));
				p.setPrezzoTasse(Util.decimali(tasseProdotto+p.getPrezzo()));
			}
			if(p.isImported() && p.isEsente()) {
				tasseProdotto =Util.arrotondoCifra((p.getPrezzo()*0.05));
				p.setPrezzoTasse(Util.decimali(tasseProdotto+p.getPrezzo()));
			}

			out.setTasseFinali(tasseProdotto);
			out.setCifraFinale(p.getPrezzoTasse());
		}

		return out;

	}


	public void aggiungiProdotto(Prodotto prodotto) {
		this.tasseTotali +=  this.getCalcoloPrezzo(prodotto).getTasseFinali();
		this.prezzoTotale += this.getCalcoloPrezzo(prodotto).getCifraFinale();
		prodotti.add(prodotto);
	}


	public double getTasseTotali() {
		return Util.decimali(tasseTotali);
	}


	public void setTasseTotali(double tasseTotali) {
		this.tasseTotali = tasseTotali;
	}


	public double getPrezzoTotale() {
		return Util.decimali(prezzoTotale);
	}


	public void setPrezzoTotale(double prezzoTotale) {
		this.prezzoTotale = prezzoTotale;
	}


	@Override
	public String toString() {
		StringBuilder result = new StringBuilder();
		result.append("Output:");
		result.append("\n");
		for (Prodotto p : prodotti) {
			result.append(p);
			result.append("\n");
		}
		result.append("SalesTaxes: ").append(this.getTasseTotali()).append("\n");
		result.append("Total: ").append(this.getPrezzoTotale());

		return result.toString();
	}


}
