package com.IDMConsulting.sales_taxes.classi;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class Util {
	
	public static double arrotondoCifra(double cifra) {
		return Math.ceil(cifra * 20.0) / 20.0;
	}
	
	public static double decimali(double cifra){
		return new BigDecimal(cifra).setScale(2, RoundingMode.HALF_UP).doubleValue();
	}
}
