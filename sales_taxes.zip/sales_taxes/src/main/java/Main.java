import java.util.*;

import com.IDMConsulting.sales_taxes.classi.Output;
import com.IDMConsulting.sales_taxes.classi.PriceService;
import com.IDMConsulting.sales_taxes.classi.Prodotto;

public class Main {
	
	public static void main(String[] args){
		
		
		
		/**
		 * INPUT 1 ------- OUTPUT 1
		 */
		
		PriceService service1= new PriceService();
		Prodotto prodotto1= new Prodotto("book", 12.49, 0.0, false, true);
		Output out1= service1.getCalcoloPrezzo(prodotto1);
		System.out.println(out1);
		service1.aggiungiProdotto(prodotto1);
		Prodotto prodotto2= new Prodotto("music CD", 14.99, 0.0, false, false);
		Output out2= service1.getCalcoloPrezzo(prodotto2);
		System.out.println(out2);
		service1.aggiungiProdotto(prodotto2);
		Prodotto prodotto3= new Prodotto("chocolate bar", 0.85, 0.0, false, true);
		Output out3= service1.getCalcoloPrezzo(prodotto3);
		System.out.println(out3);
		service1.aggiungiProdotto(prodotto3);
		
		System.out.println(service1.toString());
	

	/**
	 * INPUT 2 ------- OUTPUT 2
	 */
	System.out.println("******************************************************");
	
	PriceService service2= new PriceService();
	
	Prodotto prodotto4= new Prodotto("imported box of chocolates", 10.00, 0.0, true, true);
	Output out4= service2.getCalcoloPrezzo(prodotto4);
	System.out.println(out4);
	service2.aggiungiProdotto(prodotto4);
	Prodotto prodotto5= new Prodotto("imported bottle of perfume", 47.50, 0.0, true, false);
	Output out5= service2.getCalcoloPrezzo(prodotto5);
	System.out.println(out5);
	service2.aggiungiProdotto(prodotto5);
	
	System.out.println(service2.toString());
	
	/**
	 * INPUT 3 ------- OUTPUT 3
	 */
	System.out.println("******************************************************");
	
	PriceService service3= new PriceService();
	
	Prodotto prodotto6= new Prodotto("imported bottle of perfume", 27.99, 0.0, true, false);
	Output out6= service3.getCalcoloPrezzo(prodotto6);
	System.out.println(out6);
	service3.aggiungiProdotto(prodotto6);
	Prodotto prodotto7= new Prodotto("bottle of perfume", 18.99, 0.0, false, false);
	Output out7= service3.getCalcoloPrezzo(prodotto7);
	System.out.println(out7);
	service3.aggiungiProdotto(prodotto7);
	Prodotto prodotto8= new Prodotto("packet of headache pills ", 9.75, 0.0, false, true);
	Output out8= service3.getCalcoloPrezzo(prodotto8);
	System.out.println(out8);
	service3.aggiungiProdotto(prodotto8);
	Prodotto prodotto9= new Prodotto("imported box of chocolate", 11.25, 0.0, true, true);
	Output out9= service3.getCalcoloPrezzo(prodotto9);
	System.out.println(out9);
	service3.aggiungiProdotto(prodotto9);
	
	System.out.println(service3.toString());
}

}
