package com.IDMConsulting.sales_taxes;

import org.junit.Test;

import com.IDMConsulting.sales_taxes.classi.Output;
import com.IDMConsulting.sales_taxes.classi.PriceService;
import com.IDMConsulting.sales_taxes.classi.Prodotto;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;

import org.junit.Assert;

public class Test {
    @Test
    public void testInput1() {

        double expectedBookPrice = 12.49;
        double expectedMusicPrice = 16.49;
        double expectedChocolatePrice = 0.85;
        double totalTaxes = 1.50;
        double totalPrices = 29.83;

        PriceService receipt1 = new PriceService();
        Prodotto prodotto1= new Prodotto("book", 12.49, 0.0, false, true);
        receipt1.aggiungiProdotto(prodotto1);

        Assert.assertEquals(expectedBookPrice, prodotto1.getPrezzoTasse(), 0);

        Prodotto prodotto2= new Prodotto("music CD", 14.99, 0.0, false, false);
        receipt1.aggiungiProdotto(prodotto2);

        Assert.assertEquals(expectedMusicPrice, prodotto2.getPrezzoTasse(), 0);

		Prodotto prodotto3= new Prodotto("chocolate bar", 0.85, 0.0, false, true);
        receipt1.aggiungiProdotto(prodotto3);

        Assert.assertEquals(expectedChocolatePrice, prodotto3.getPrezzoTasse(), 0);
        Assert.assertEquals(totalTaxes, receipt1.getTasseTotali(), 0);
        Assert.assertEquals(totalPrices, receipt1.getPrezzoTotale(), 0);

        System.out.println(receipt1);
    }

    @Test
    public void testInput2() {

        double expectedimportedChocolatePrice = 10.50;
        double expectedImportedBottlePerfumePrice = 54.65;
        double totalTaxes = 7.65;
        double totalPrices = 65.15;

        PriceService receipt2 = new PriceService();
        Prodotto prodotto4= new Prodotto("imported box of chocolates", 10.00, 0.0, true, true);
        receipt2.aggiungiProdotto(prodotto4);

        Assert.assertEquals(expectedimportedChocolatePrice, prodotto4.getPrezzoTasse(), 0);

    	Prodotto prodotto5= new Prodotto("imported bottle of perfume", 47.50, 0.0, true, false);
        receipt2.aggiungiProdotto(prodotto5);

        Assert.assertEquals(expectedImportedBottlePerfumePrice, prodotto5.getPrezzoTasse(), 0);

        Assert.assertEquals(totalTaxes, receipt2.getTasseTotali(), 0);
        Assert.assertEquals(totalPrices, receipt2.getPrezzoTotale(), 0);

        System.out.println(receipt2);
    }

    @Test
    public void testInput3() {

        double expectedImportedBottlePerfumePrice = 32.19;
        double expectedBottlePerfumePrice = 20.89;
        double expectedPacketHeadachePillsPrice = 9.75;
        double expectedimportedChocolatePrice = 11.85;
        double totalTaxes = 6.70;
        double totalPrices = 74.68;

        PriceService receipt3 = new PriceService();

        Prodotto prodotto6 = new Prodotto("imported bottle of perfume", 27.99, 0, true, false);
        receipt3.aggiungiProdotto(prodotto6);

        Assert.assertEquals(expectedImportedBottlePerfumePrice, prodotto6.getPrezzoTasse(), 0);

        Prodotto prodotto7 = new Prodotto("bottle of perfume", 18.99, 0, false, false);
        receipt3.aggiungiProdotto(prodotto7);

        Assert.assertEquals(expectedBottlePerfumePrice, prodotto7.getPrezzoTasse(), 0);

        Prodotto prodotto8 = new Prodotto("packet of headache pills ", 9.75, 0, false, true);
        receipt3.aggiungiProdotto(prodotto8);

        Assert.assertEquals(expectedPacketHeadachePillsPrice, prodotto8.getPrezzoTasse(), 0);

        Prodotto prodotto9 = new Prodotto("imported box of chocolate", 11.25, 0, true, false);
        receipt3.aggiungiProdotto(prodotto9);

        Assert.assertEquals(expectedimportedChocolatePrice, prodotto9.getPrezzoTasse(), 0);

        Assert.assertEquals(totalTaxes, receipt3.getTasseTotali(), 0);
        Assert.assertEquals(totalPrices, receipt3.getPrezzoTotale(), 0);

        System.out.println(receipt3);
    }

}
